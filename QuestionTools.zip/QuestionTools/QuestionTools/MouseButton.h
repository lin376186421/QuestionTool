//
//  MouseButton.h
//  QuestionTools
//
//  Created by 林 on 2017/5/25.
//  Copyright © 2017年 林. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MouseButton : NSButton

@property (nonatomic, strong) NSImage *highlightImage;

@end
