//
//  LogViewController.h
//  QuestionTools
//
//  Created by 林 on 2017/5/19.
//  Copyright © 2017年 林. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface LogViewController : NSWindowController

- (void)reloadData;
- (void)addLog;

@end
