//
//  JKBD_DB.h
//  333
//
//  Created by cheng on 17/5/5.
//  Copyright © 2017年 Chelun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Base_DB.h"

@interface JKBD_DB : Base_DB

- (void)dealJKBDKnowledge;
- (void)dealJKBDKnowledgeId;
- (void)dealJKBDKnowledgeItem;

@end
