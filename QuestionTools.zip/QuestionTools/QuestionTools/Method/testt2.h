//
//  testt2.h
//  333
//
//  Created by cheng on 2017/9/29.
//  Copyright © 2017年 Chelun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface testt2 : NSObject

@end
