//
//  SqlString.h
//  333
//
//  Created by cheng on 2017/7/25.
//  Copyright © 2017年 Chelun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SqlString : NSObject

+ (NSString *)sqlWithIndex:(NSInteger)index;

@end
