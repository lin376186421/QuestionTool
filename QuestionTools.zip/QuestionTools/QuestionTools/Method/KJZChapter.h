//
//  KJZChapter.h
//  333
//
//  Created by cheng on 17/5/5.
//  Copyright © 2017年 Chelun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface KJZChapter : NSObject

+ (void)resetKaojiazhaoChapter;

+ (void)updateKaojiazhaoChapter;

@end
