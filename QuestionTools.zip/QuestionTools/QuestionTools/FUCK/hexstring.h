//
// Created by zhangai on 16/4/5.
//

#ifndef FUCK_HEXSTRING_H
#define FUCK_HEXSTRING_H


uint8_t *hexStringToBytes(char *inhex);

char *bytesToHexString(uint8_t *bytes, size_t buflen);

#endif //FUCK_HEXSTRING_H
