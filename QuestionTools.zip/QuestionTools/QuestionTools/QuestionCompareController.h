//
//  QuestionCompareController.h
//  QuestionTools
//
//  Created by cheng on 2017/9/29.
//  Copyright © 2017年 林. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface QuestionCompareController : NSWindowController

@end
